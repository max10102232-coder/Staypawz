// Sample sitter data
const SAMPLE_SITTERS = [
  {
    id: 'sarah-sw11',
    name: 'Sarah W.',
    location: 'London, SW11',
    postcode: 'SW11',
    pricePerNight: 35,
    bio: 'Lifelong dog lover, experienced with small breeds. Home with secure garden.',
    badges: ['ID verified', 'DBS checked'],
    experienceYears: 5,
    image: 'https://images.unsplash.com/photo-1559239115-6f4f0f7a48d4?q=80&w=900&auto=format&fit=crop&ixlib=rb-4.0.3&s=7f3d9f1db1f2b7cfccb0e6b6c1a2b1ee',
    reviews: [{ name: 'Alice', rating: 5, text: 'Amazing care and daily photos — Ruby loved it.' }]
  },
  {
    id: 'tom-ella-m3',
    name: 'Tom & Ella',
    location: 'Manchester, M3',
    postcode: 'M3',
    pricePerNight: 40,
    bio: 'Quiet home, big living room and no other pets. Walks twice daily.',
    badges: ['ID verified', 'Trial stay passed'],
    experienceYears: 3,
    image: 'https://images.unsplash.com/photo-1518717758536-85ae29035b6d?q=80&w=900&auto=format&fit=crop&ixlib=rb-4.0.3&s=50b6d8be8f3b7f2f60cb2b9f04c8a7a9',
    reviews: [{ name: 'Mark', rating: 4, text: 'Friendly hosts. Marvin came back happy.' }]
  },
  {
    id: 'jo-bs8',
    name: 'Jo R.',
    location: 'Bristol, BS8',
    postcode: 'BS8',
    pricePerNight: 45,
    bio: 'Former vet nurse, offers 24/7 care and medicine administration.',
    badges: ['DBS checked', 'Canine First Aid'],
    experienceYears: 8,
    image: 'https://images.unsplash.com/photo-1507149833265-60c372daea22?q=80&w=900&auto=format&fit=crop&ixlib=rb-4.0.3&s=6e1b6f3b4a9b5d8d6c2f6d1a2a9e9f0f',
    reviews: [{ name: 'Sophie', rating: 5, text: 'Phenomenal care — they saved us when our flight delayed.' }]
  }
];

const sitterList = document.getElementById('sitterList');
const searchInput = document.getElementById('searchInput');
const minPriceInput = document.getElementById('minPrice');
const maxPriceInput = document.getElementById('maxPrice');
const searchBtn = document.getElementById('searchBtn');
const modal = document.getElementById('modal');
const modalContent = document.getElementById('modalContent');
const closeModal = document.getElementById('closeModal');

function renderSitters(sitters) {
  sitterList.innerHTML = '';
  if (sitters.length === 0) {
    sitterList.innerHTML = '<div class="p-6 bg-white rounded-lg shadow text-center text-gray-600">No sitters matched your search. Try widening the area or price range.</div>';
    return;
  }
  sitters.forEach(s => {
    const card = document.createElement('article');
    card.className = 'bg-white rounded-xl shadow p-4 flex gap-4 items-start';
    card.innerHTML = `
      <img src="${s.image}" alt="${s.name}" class="w-28 h-28 object-cover rounded-lg" />
      <div class="flex-1">
        <div class="flex items-start justify-between">
          <div>
            <h4 class="text-lg font-semibold">${s.name}</h4>
            <p class="text-sm text-gray-500">${s.location} • ${s.experienceYears} yrs experience</p>
          </div>
          <div class="text-right">
            <div class="text-lg font-bold">£${s.pricePerNight}</div>
            <div class="text-xs text-gray-500">per night</div>
          </div>
        </div>
        <p class="mt-2 text-sm text-gray-700">${s.bio}</p>
        <div class="mt-3 flex items-center gap-2 flex-wrap">
          ${s.badges.map(b => `<span class="text-xs px-2 py-1 bg-gray-100 rounded-full">${b}</span>`).join('')}
        </div>
        <div class="mt-3 flex gap-2">
          <button data-id="${s.id}" class="viewProfileBtn px-3 py-1 rounded-md border">View profile</button>
          <button onclick="alert('Message feature mock — integrate messaging API in production')" class="px-3 py-1 rounded-md border">Message sitter</button>
        </div>
      </div>
    `;
    sitterList.appendChild(card);
  });

  document.querySelectorAll('.viewProfileBtn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = e.currentTarget.getAttribute('data-id');
      const sitter = SAMPLE_SITTERS.find(s => s.id === id);
      openModal(sitter);
    });
  });
}

function openModal(s) {
  modalContent.innerHTML = `
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
      <img src="${s.image}" alt="${s.name}" class="w-full h-48 object-cover rounded-lg md:col-span-1" />
      <div class="md:col-span-2">
        <h3 class="text-2xl font-bold">${s.name}</h3>
        <p class="text-sm text-gray-600">${s.location} • £${s.pricePerNight}/night</p>
        <p class="mt-4 text-gray-700">${s.bio}</p>
        <div class="mt-4">
          <h4 class="font-medium">Reviews</h4>
          <div class="mt-2 space-y-2">
            ${s.reviews.map(r => `<div class="text-sm"><strong>${r.name}</strong> — <span class="text-yellow-500">${'★'.repeat(r.rating)}</span><div class="text-gray-600">${r.text}</div></div>`).join('')}
          </div>
        </div>
        <div class="mt-6">
          <h4 class="font-medium">Book a stay (demo)</h4>
          <form onsubmit="event.preventDefault(); alert('Demo booking requested — this is view-only.');">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mt-3">
              <label class="flex flex-col text-sm">Your name<input required class="mt-1 px-3 py-2 border rounded-md" /></label>
              <label class="flex flex-col text-sm">Email<input type="email" required class="mt-1 px-3 py-2 border rounded-md" /></label>
              <label class="flex flex-col text-sm">Start date<input type="date" required class="mt-1 px-3 py-2 border rounded-md" /></label>
              <label class="flex flex-col text-sm">End date<input type="date" required class="mt-1 px-3 py-2 border rounded-md" /></label>
              <div class="md:col-span-2 flex items-center justify-between">
                <div class="text-sm text-gray-600">Total estimate: <strong>£${s.pricePerNight} × nights</strong></div>
                <button type="submit" class="px-4 py-2 bg-emerald-500 text-white rounded-md">Request booking</button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  `;
  modal.classList.remove('hidden');
  modal.classList.add('flex');
}

closeModal.addEventListener('click', () => {
  modal.classList.add('hidden');
  modal.classList.remove('flex');
});

searchBtn.addEventListener('click', () => {
  const q = searchInput.value.trim().toLowerCase();
  const min = Number(minPriceInput.value) || 0;
  const max = Number(maxPriceInput.value) || Infinity;
  const results = SAMPLE_SITTERS.filter(s => {
    const matches = q === '' || s.postcode.toLowerCase().includes(q) || s.location.toLowerCase().includes(q);
    return matches && s.pricePerNight >= min && s.pricePerNight <= max;
  });
  renderSitters(results);
});

// initial render
renderSitters(SAMPLE_SITTERS);
