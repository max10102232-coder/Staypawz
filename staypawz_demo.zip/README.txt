StayPawz - View-only static demo
-------------------------------
This is a simple view-only static website (HTML + Tailwind + vanilla JS) for the StayPawz concept.

How to use:
1. Unzip the archive.
2. Open index.html in your browser to view the demo locally.
3. To publish: upload the files to GitHub (create repo) and deploy via Vercel or GitHub Pages.

Files included:
- index.html
- script.js

Note: This is a demo. Booking and messaging features are mocked (no backend, no payments).
